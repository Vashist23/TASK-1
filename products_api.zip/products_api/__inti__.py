import azure.functions as func
import json
import logging
from azure.cosmos import CosmosClient
import os

# Load Cosmos DB settings
COSMOS_URI = os.getenv("COSMOS_URI")
COSMOS_KEY = os.getenv("COSMOS_KEY")
DATABASE_NAME = os.getenv("COSMOS_DB")
CONTAINER_NAME = os.getenv("COSMOS_CONTAINER")

# Create client
client = CosmosClient(COSMOS_URI, COSMOS_KEY)
database = client.get_database_client(DATABASE_NAME)
container = database.get_container_client(CONTAINER_NAME)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing request...")

    method = req.method
    product_id = req.route_params.get("id")

    # -------------------------------
    # CREATE PRODUCT (POST)
    # -------------------------------
    if method == "POST":
        try:
            body = req.get_json()
        except:
            return func.HttpResponse("Invalid JSON", status_code=400)

        if "id" not in body:
            return func.HttpResponse("id is required", status_code=400)
        if "price" not in body or not isinstance(body["price"], (int, float)):
            return func.HttpResponse("price must be numeric", status_code=400)

        try:
            container.create_item(body)
            return func.HttpResponse(json.dumps(body), status_code=201, mimetype="application/json")
        except Exception as e:
            return func.HttpResponse(str(e), status_code=400)

    # -------------------------------
    # LIST PRODUCTS (GET)
    # -------------------------------
    if method == "GET" and product_id is None:
        items = list(container.read_all_items())
        return func.HttpResponse(json.dumps(items), status_code=200, mimetype="application/json")

    # -------------------------------
    # GET PRODUCT BY ID
    # -------------------------------
    if method == "GET" and product_id:
        try:
            item = container.read_item(item=product_id, partition_key=product_id)
            return func.HttpResponse(json.dumps(item), status_code=200, mimetype="application/json")
        except:
            return func.HttpResponse("Product not found", status_code=404)

    # -------------------------------
    # UPDATE PRODUCT (PUT)
    # -------------------------------
    if method == "PUT":
        try:
            body = req.get_json()
        except:
            return func.HttpResponse("Invalid JSON", status_code=400)

        try:
            item = container.read_item(item=product_id, partition_key=product_id)
        except:
            return func.HttpResponse("Product not found", status_code=404)

        item.update(body)
        container.upsert_item(item)
        return func.HttpResponse(json.dumps(item), status_code=200, mimetype="application/json")

    # -------------------------------
    # DELETE PRODUCT (DELETE)
    # -------------------------------
    if method == "DELETE":
        try:
            container.delete_item(item=product_id, partition_key=product_id)
            return func.HttpResponse(status_code=204)
        except:
            return func.HttpResponse("Product not found", status_code=404)

    return func.HttpResponse("Invalid request", status_code=400)
